var searchData=
[
  ['buttonheight',['buttonHeight',['../_net_funnel_wait_view_8m.html#a127aed37a69d152b12d19a37e962eb40',1,'NetFunnelWaitView.m']]],
  ['buttonspacerheight',['buttonSpacerHeight',['../_net_funnel_wait_view_8m.html#abc348485da548a6ec03e12142f0c4820',1,'NetFunnelWaitView.m']]]
];
