var searchData=
[
  ['delegate',['delegate',['../interface_net_funnel_custom_alert_view.html#ad5024d565fb83470d2b4372ee2c8c43f',1,'NetFunnelCustomAlertView']]],
  ['dialogview',['dialogView',['../interface_net_funnel_custom_alert_view.html#a96af9ebf7000caab3b5e62dc1b6d20cb',1,'NetFunnelCustomAlertView']]]
];
