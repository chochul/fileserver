var searchData=
[
  ['initaildata',['initailData',['../interface_net_funnel_wait_view.html#ad1f8710be15995a46c12d54f38f22e06',1,'NetFunnelWaitView']]],
  ['initwithdata_3a',['initWithData:',['../interface_net_funnel_result.html#a2f697c3ed85e9a6a7d6819308a45c32d',1,'NetFunnelResult']]],
  ['initwithdelegate_3apview_3a',['initWithDelegate:pView:',['../interface_net_funnel.html#a80b831a8d8a19e24526d9c651a509a08',1,'NetFunnel']]],
  ['initwithdelegate_3apview_3awithconfig_3a',['initWithDelegate:pView:withConfig:',['../interface_net_funnel.html#ad2aeded4b1d6a6ab9bf98acbc74043c2',1,'NetFunnel']]],
  ['initwithparentview_3a',['initWithParentView:',['../interface_net_funnel_custom_alert_view.html#a74af189c6fd176413bfbc9f65a1a05e3',1,'NetFunnelCustomAlertView::initWithParentView:()'],['../interface_net_funnel_wait_view.html#a6e2e2a4364ededdcccd96355200da00d',1,'NetFunnelWaitView::initWithParentView:()']]],
  ['itemforkey_3a',['itemForKey:',['../interface_net_funnel_info_storage.html#adff43dcfe9528fbc67531fda7a1eb1b4',1,'NetFunnelInfoStorage']]]
];
