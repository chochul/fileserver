//
//  ViewController.swift
//  SwiftApp
//
//  Created by mhpark on 2020/05/20.
//  Copyright © 2020 mhpark. All rights reserved.
//

import UIKit

import Foundation
import NetFunnel


enum NetFunnelCode: Int {
    case Success = 200
    case Continue = 201
    case Continue2 = 202
    case UserStop = 203
    case NotUsed = 204
    case ContinueInterval = 211
    case Bypass = 300
    case Block = 301
    case IpBlock = 302
    case ExpressMember = 303
    case Error = 500
}

//#if FLAG_TB
let kNetFunnelJoin = (nid: "apptest", aid: "apptest")
let kNetFunnelCharge = (nid: "act_2", aid: "act_2")
let kNetFunnelLaunch = (nid: "act_3", aid: "act_3")
let kNetFunnelPayQR = (nid: "act_4", aid: "act_4")
//#else
//let kNetFunnelJoin = (nid: "1", aid: "act_1")
//let kNetFunnelCharge = (nid: "2", aid: "action_goodpay_2")
//let kNetFunnelLaunch = (nid: "3", aid: "action_goodpay_3")
//let kNetFunnelPayQR = (nid: "4", aid: "action_goodpay_4")
//#endif


class NetFunnelManager: UIViewController, NetFunnelDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

        @IBAction func act1Action(_ sender:  UIButton) {
            print("act1Action")
            setup(nid: kNetFunnelJoin.nid, aid: kNetFunnelJoin.aid)
            netFunnel?.action(withNid: kNetFunnelJoin.nid, config: nil)

        }
        
        @IBAction func act1Complete(_ sender: UIButton) {
            print("act1Complete")
            setup(nid: kNetFunnelJoin.nid, aid: kNetFunnelJoin.aid)
            netFunnel?.complete(withNid: kNetFunnelJoin.nid, config: nil)
        }

    @IBAction func act2Action(_ sender: UIButton) {
            print("act1Action")
            setup(nid: kNetFunnelCharge.nid, aid: kNetFunnelCharge.aid)
            netFunnel?.action(withNid: kNetFunnelCharge.nid, config: nil)
    
    }
    
    @IBAction func act2Complete(_ sender: UIButton) {
            print("act1Complete")
            setup(nid: kNetFunnelCharge.nid, aid: kNetFunnelCharge.aid)
            netFunnel?.complete(withNid: kNetFunnelCharge.nid, config: nil)
    }
    
    static let instance = NetFunnelManager()

    var nf_yn: String = "NNNN"

    let waitView = NetFunnelWaitViewImpl()
    var netFunnel: NetFunnel?
    var reqStatus = Dictionary<String, Bool>()
    
    var callback: ((_ code:Int)->())?

    
    
    func setup(nid:String, aid:String) {
    
        netFunnel = NetFunnel.init(delegate: self, pView: self.view)
        
        NetFunnel.setGlobalConfigObject(waitView, forKey:"wait_view_object", withId: nid)
        NetFunnel.setGlobalConfigObject("https", forKey:"proto", withId:nid)
        NetFunnel.setGlobalConfigObject("nf2.netfunnel.co.kr", forKey:"host", withId:nid)
        NetFunnel.setGlobalConfigObject(443, forKey:"port", withId:nid)
        NetFunnel.setGlobalConfigObject("service_6", forKey:"service_id", withId:nid)
        NetFunnel.setGlobalConfigObject(aid, forKey:"action_id", withId:nid)
    }
    
    func actionLaunch(callback:@escaping (_ isSuccess:Bool)->()) {

        if !isActionOn(2) {
            callback(true)
            return
        }
        
        action(id:kNetFunnelLaunch) { (code) in

            switch NetFunnelCode(rawValue: code) {
            case .Success:
                self.alive(nid: kNetFunnelLaunch.nid)
                callback(true)
            case .Continue, .Continue2, .ContinueInterval:
                () //대기
            case .UserStop:
//                CommonPopupVC.present(UIApplication.topViewController()!, type: .one) {
//                    $0.detailText = "앱을 종료합니다."
//                    $0.oneBtnSelected = { exit(0) }
//                }
            ()
                
            case .Block, .IpBlock:
//                CommonPopupVC.present(UIApplication.topViewController()!, type: .one) {
//                    $0.detailText = "블럭 되었습니다."
//                    $0.oneBtnSelected = { exit(0) }
//                }
                ()
            default:
                callback(true)
            }
        }
    }
    
    func actionJoin(callback:@escaping (_ isSuccess:Bool)->()) {
        
        if !isActionOn(0) {
            callback(true)
            return
        }
        
        action(id:kNetFunnelJoin) { (code) in
            
            switch NetFunnelCode(rawValue: code) {
            case .Success:
                self.alive(nid: kNetFunnelJoin.nid)
                callback(true)
            case .Continue, .Continue2, .ContinueInterval:
                () //대기
            case .UserStop:
//                CommonPopupVC.present(UIApplication.topViewController()!, type: .one) {
//                    $0.detailText = "앱을 종료합니다."
//                    $0.oneBtnSelected = { exit(0) }
//                }
                ()
            case .Block, .IpBlock:
//                CommonPopupVC.present(UIApplication.topViewController()!, type: .one) {
//                    $0.detailText = "블럭 되었습니다."
//                    $0.oneBtnSelected = { exit(0) }
//                }
                ()
            default:
                callback(true)
            }
        }
    }
    
    func actionCharge(callback:@escaping (_ isSuccess:Bool)->()) {
        
        if !isActionOn(1) {
            callback(true)
            return
        }
        
        action(id:kNetFunnelCharge) { (code) in
            
            switch NetFunnelCode(rawValue: code) {
            case .Success:
                self.alive(nid: kNetFunnelCharge.nid)
                callback(true)
            case .Continue, .Continue2, .ContinueInterval:
                () // 대기
            case .UserStop:
                callback(false)
            case .Block, .IpBlock:
//                CommonPopupVC.present(UIApplication.topViewController()!, type: .one) {
//                    $0.detailText = "블럭 되었습니다."
//                }
                ()
            default:
                callback(true)
            }
        }

    }
    
    func actionPayQR(callback:@escaping (_ isSuccess:Bool)->()) {
        
        if !isActionOn(3) {
            callback(true)
            return
        }
        
        action(id:kNetFunnelPayQR) { (code) in
            
            switch NetFunnelCode(rawValue: code) {
            case .Success:
                self.alive(nid: kNetFunnelPayQR.nid)
                callback(true)
            case .Continue, .Continue2, .ContinueInterval:
                () // 대기
            case .UserStop:
                callback(false)
            case .Block, .IpBlock:
//                CommonPopupVC.present(UIApplication.topViewController()!, type: .one) {
//                    $0.detailText = "블럭 되었습니다."
//                }
                ()
            default:
                callback(true)
            }
        }
    }
    
    
    func isActionOn(_ index:Int) -> Bool
    {
        //let char = nf_yn.makeSubString(startIndex: index, count: 1)
        return true//char == "Y"
    }
    
    private func action(id:(nid:String, aid:String), cb:@escaping (_ code:Int)->()) {

        print("@@\(Date()) \(#function) nid:\(id.nid)")
        
        callback = cb
        setup(nid:id.nid, aid:id.aid)
        netFunnel?.action(withNid: id.nid, config: nil)
    }
    
    func alive(nid: String) {
        
        if reqStatus[nid] != true { return }
        
        print("@@\(Date()) \(#function) nid:\(nid)")

        netFunnel?.alive(withNid: nid, config: nil)
    }
    
    func complete(nid: String) {
        
        if reqStatus[nid] != true { return }
        
        reqStatus[nid] = false

        print("@@\(Date()) \(#function) nid:\(nid)")

        netFunnel?.complete(withNid: nid, config: nil)
    }
    
    func completeAll() {
        
        complete(nid: kNetFunnelLaunch.nid)
        complete(nid: kNetFunnelJoin.nid)
        complete(nid: kNetFunnelCharge.nid)
        complete(nid: kNetFunnelPayQR.nid)
    }
    
    
    // NetFunnelDelegate
    /**
     Action요청 성공시에 호출되는 method (required)
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     */
    func netFunnelActionSuccess(_ nid: String!, with result: NetFunnelResult?) {
        
        resultLog(funcName: #function, nid: nid, result: result)
        
//        reqStatus[nid] = true
//
//        callback?(result?._retcode ?? NetFunnelCode.Success.rawValue)
//
        netFunnel?.alive(withNid: nid, config: nil)
    }
    /**
     Complete요청 성공시에 호출되는 method (required)
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     */
    func netFunnelCompleteSuccess(_ nid: String!, with result: NetFunnelResult?) {
                
        resultLog(funcName: #function, nid: nid, result: result)
    }
    /**
     Action요청 - Continue 응답시에 호출되는 method (optional)
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     @return BOOL WaitView를 보여줄지 말지를 결정한다. NO로 전달되면 대기창이 보여지지 않는다.
     */
    func netFunnelActionContinue(_ nid: String!, with result: NetFunnelResult?) -> Bool {
        
        resultLog(funcName: #function, nid: nid, result: result)
        
        callback?(result?._retcode ?? NetFunnelCode.Continue.rawValue)
        
        return true
    }
    /**
     Action요청 - Error 응답시에 호출되는 method (optional)
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     */
    func netFunnelActionError(_ nid: String!, with result: NetFunnelResult?) {
        
        resultLog(funcName: #function, nid: nid, result: result)
        
        callback?(result?._retcode ?? NetFunnelCode.Error.rawValue)
    }
    /**
     Action요청 - Block 응답시에 호출되는 method (optional)
        - WebAdmin에서 Service나 Action 설정을 Block으로 선택한경우에 전달되는 응답이다.
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     @return BOOL Default 차단 메세지를 보여줄지 말지를 결정한다. NO로 전달되면 메세지가 보여지지 않는다.
     */
    func netFunnelActionBlock(_ nid: String!, with result: NetFunnelResult?) -> Bool {
        
        resultLog(funcName: #function, nid: nid, result: result)
        
        complete(nid: nid)

        callback?(result?._retcode ?? NetFunnelCode.Block.rawValue)
        
        return false
    }
    /**
     Action요청 - IpBlock 응답시에 호출되는 method (optional)
        - Access Control에 의해서 차단된 사용자에게 전달되는 응답.
        - Default로 가상대기창을 출력한다.
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     @return BOOL Default 차단 메세지를 보여줄지 말지와 대기후 재시도를 할지를 결정한다. NO로 전달되면 메세지가 보여지지 않고 대기후 재시도도 하지 않는다.
     */
    func netFunnelActionIpBlock(_ nid: String!, with result: NetFunnelResult?) -> Bool {
        
        resultLog(funcName: #function, nid: nid, result: result)
        
        complete(nid: nid)

        callback?(result?._retcode ?? NetFunnelCode.IpBlock.rawValue)
        
        return false
    }
    /**
     Alive요청 - Continue 응답시에 호출되는 method (optional)
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     */
    func netFunnelAliveNoticeContinue(_ nid: String!, with result: NetFunnelResult?) {
        
        resultLog(funcName: #function, nid: nid, result: result)
    }
    /**
     Alive요청 - Error 응답시에 호출되는 method (optional)
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     */
    func netFunnelAliveNoticeError(_ nid: String!, with result: NetFunnelResult?) {
        
        resultLog(funcName: #function, nid: nid, result: result)
    }
    /**
     Alive요청 - Bloc 응답시에 호출되는 method (optional)
         - WebAdmin에서 Service나 Action 설정을 Block으로 선택한경우에 전달되는 응답이다.
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     */
    func netFunnelAliveNoticeBlock(_ nid: String!, with result: NetFunnelResult?) {
        
        resultLog(funcName: #function, nid: nid, result: result)
    }
    /**
     Action요청 - IpBlock 응답시에 호출되는 method (optional)
     - Access Control에 의해서 차단된 사용자에게 전달되는 응답.
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     */
    func netFunnelAliveNoticeIpBlock(_ nid: String!, with result: NetFunnelResult?) {
        
        resultLog(funcName: #function, nid: nid, result: result)
    }
    /**
     Complete요청 - Error 응답시에 호출되는 method (optional)
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     @param result NetFUNNEL 호출 결과 값
     */
    func netFunnelCompleteError(_ nid: String!, with result: NetFunnelResult?) {
        
        resultLog(funcName: #function, nid: nid, result: result)
    }
    /**
     Stop 요청이 호출되었을때 실행되는 method (optional)
     @param nid 요청구분을 위해 요청시에 전달했던 요청ID값
     */
    func netFunnelStop(_ nid: String!) {
        resultLog(funcName: #function, nid: nid, result: nil)
        
callback?(NetFunnelCode.UserStop.rawValue)
    }
    
    func resultLog(funcName: String, nid: String, result: NetFunnelResult?) {
        
        print("@@\(Date()) \(funcName) nid:\(nid) code:\(String(describing: result?._retcode)) data:\(String(describing: result?._data))")
    }

}
