//
//  NFWaitView.swift
//  localpay
//
//  Created by tale on 2020/04/24.
//  Copyright © 2020 blucean. All rights reserved.
//

import UIKit
import Foundation
import NetFunnel


class NFWaitView: UIView {
    
    @IBOutlet var title: UILabel!
    @IBOutlet var desc: UILabel!
//    @IBOutlet var progress: UIProgressView!
    @IBAction func onClickStop(_ sender: Any) {
        
        stopAction?();
    }
    
    var stopAction: (()->())?

    static func create() -> NFWaitView {
        let view = Bundle.main.loadNibNamed("NFWaitView", owner:self, options:nil)?.first as! NFWaitView
        return view;
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.frame = UIScreen.main.bounds;
        self.backgroundColor = UIColor.green
    }
    
    func onUpdate(data: NetFunnelWaitData) {
     
        //print("@@ progress : \(data._progress)") // 진행율
        
//        if(_alert != nil){
//            [_alert close];
//            _alert = nil;
//        }
        
        var total = data._waitTime
        
        let hour = total/3600
        total = total%3600
        let min = total/60
        total = total%60
        let sec = total

        var timeStr = ""
        if hour > 0 {
            timeStr = String(format: "%2d시 %2d분 %2d초", hour, min, sec)
        }
        else if min > 0 {
            timeStr = String(format: "%2d분 %2d초", min, sec)
        }
        else {
            timeStr = String(format: "%2d초", sec)
        }
        
        title.text = "현재 사용자가 많아 접속 대기 중입니다."
        desc.text = """
        현재 대기 인원은 \(data._waitUser)명이고,
        예상 대기시간은 \(timeStr) 입니다.
        
        잠시만 기다려 주시면 서비스로 자동 접속합니다.
        """
        
//      progress.setProgress(data._progress, animated: true)
    }
    

}

class NetFunnelWaitViewImpl: NetFunnelWaitView, NetFunnelWaitViewProtocol {
    
    var waitView: NFWaitView?
    
    // NetFunnelWaitViewProtocol
    func show() {
        print("@@\(Date()) NetFunnelWaitView -\(#function)")

        if waitView == nil {
            waitView =  NFWaitView.create()
            waitView?.stopAction = stop

            UIApplication.getTopViewController()?.view.addSubview(waitView!)

        }
        
        let wdata = getWaitData()
        waitView?.onUpdate(data: wdata!)
    }
    
    func stop() {
        print("@@\(Date()) NetFunnelWaitView -\(#function)")

       // NetFunnelManager.instance.setup(nid: "apptest", aid: "apptest")
        
        let nid:String = "apptest"
        let aid:String = "apptest"
         
    //    NetFunnel.setGlobalConfigObject(waitView, forKey:"wait_view_object", withId: nid)
        NetFunnel.setGlobalConfigObject("https", forKey:"proto", withId:nid)
        NetFunnel.setGlobalConfigObject("nf2.netfunnel.co.kr", forKey:"host", withId:nid)
        NetFunnel.setGlobalConfigObject(443, forKey:"port", withId:nid)
        NetFunnel.setGlobalConfigObject("service_6", forKey:"service_id", withId:nid)
        NetFunnel.setGlobalConfigObject(aid, forKey:"action_id", withId:nid)
        
        
        setStop();
//      hide()
    }
    
    func hide() {
        print("@@\(Date()) NetFunnelWaitView -\(#function)")

        waitView?.removeFromSuperview()
        waitView = nil
    }
    
    func showVirtualWait() {
        print("@@showVirtualWait")
    }
    
    func showBlockAlert() {
        print("@@showBlockAlert")
    }
    
}

extension UIApplication {

    class func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {

        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)

        } else if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopViewController(base: selected)

        } else if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}
