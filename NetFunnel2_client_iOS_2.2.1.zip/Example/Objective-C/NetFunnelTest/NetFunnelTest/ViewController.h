//
//  ViewController.h
//  NetFunnelTest
//
//  Created by Aimtog on 10/05/2019.
//  Copyright © 2019 Aimtog. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <NetFunnel/NetFunnel.h>


@interface ViewController : UIViewController <NetFunnelDelegate>

- (void)initValue:(NSString *)nid;

- (IBAction)actionClick:(id)sender;
- (IBAction)action2Click:(id)sender;
- (IBAction)action3Click:(id)sender;

- (IBAction)completeClick:(id)sender;
- (IBAction)complete2Click:(id)sender;


@end

