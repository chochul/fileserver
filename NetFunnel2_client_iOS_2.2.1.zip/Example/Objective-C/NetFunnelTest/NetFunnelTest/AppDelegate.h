//
//  AppDelegate.h
//  NetFunnelTest
//
//  Created by Aimtog on 10/05/2019.
//  Copyright © 2019 Aimtog. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

