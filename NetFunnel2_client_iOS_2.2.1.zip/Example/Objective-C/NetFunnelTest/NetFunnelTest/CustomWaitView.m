//
//  CustomWaitView.m
//  NetFunnelTest
//
//  Created by Aimtog on 10/05/2019.
//  Copyright © 2019 Aimtog. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CustomWaitView.h"
#import <NetFunnel/NetFunnelDefine.h>




// ---------------------------------------------------------------------
// NetFunnelCustomAlertView (사용자 정의 컨테이너 - 외각 작업 등)
// ---------------------------------------------------------------------
@implementation NetFunnelCustomAlertView

CGFloat buttonHeight = 0;
CGFloat buttonSpacerHeight = 0;

@synthesize parentView, containerView, dialogView, buttonView;
@synthesize delegate;
@synthesize buttonTitles;

- (id)initWithParentView: (UIView *)_parentView
{
    self = [super initWithFrame:_parentView.frame];
    
    if (self) {
        parentView = _parentView;
        delegate = self;
        buttonTitles = @[];
        containerView = nil;
    }
    return self;
}

// Create the dialog view, and animate opening the dialog
- (void)show
{
    dialogView = [self createContainerView];
    
    
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    
    [self addSubview:dialogView];
    [parentView addSubview:self];
}

// Dialog close animation then cleaning and removing the view from the parent
- (void)close
{
    for (UIView *v in [self subviews]) {
        [v removeFromSuperview];
    }
    [self removeFromSuperview];
}

- (void)setSubView: (UIView *)subView
{
    //DebugLog(@"oieurowieuroweiur");
    containerView = subView;
}

// Creates the container view here: create the dialog, then add the custom content and buttons
- (UIView *)createContainerView
{
     if (containerView == NULL) {
         containerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 50)];
     }

     CGFloat dialogWidth = containerView.frame.size.width;
     CGFloat dialogHeight = containerView.frame.size.height;
     
     CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
     CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
     
//     UIDeviceOrientation deviceOrientation = [[UIDevice currentDevice] orientation];
//     if (UIDeviceOrientationIsLandscape(deviceOrientation)) {
//         CGFloat tmp = screenWidth;
//         screenWidth = screenHeight;
//         screenHeight = tmp;
//     }
    
     // For the black background
     [self setFrame:CGRectMake(0, 0, screenWidth, screenHeight)];


     // 대화상자 컨테이너 모양 - 커스텀 콘텐츠를 첨부한다
     // This is the dialog's container; we attach the custom content and the buttons to this one
     UIView *dialogContainer = [[UIView alloc] initWithFrame:CGRectMake((screenWidth - dialogWidth) / 2, (screenHeight - dialogHeight) / 2, dialogWidth, dialogHeight)];//rectangle
     //UIView *dialogContainer = [[UIView alloc] initWithFrame:CGRectMake((screenWidth - dialogWidth) / 2, (screenHeight - dialogHeight) / 2,250,250)];//circle


    
     // 외부 테두리 덧붙이기
     [dialogContainer setBackgroundColor:RGB(245,245,245,1)];
     //dialogContainer.clipsToBounds = YES;//circle
     //dialogContainer.layer.cornerRadius = dialogContainer.frame.size.width/2.f;rectangle
     dialogContainer.layer.cornerRadius = 7;
     dialogContainer.layer.borderWidth = 2;
     dialogContainer.layer.borderColor = [RGB(255, 0, 0, 1) CGColor];
     dialogContainer.layer.shadowRadius = 0;
     dialogContainer.layer.shadowOpacity = 0.0f;
     dialogContainer.layer.shadowOffset = CGSizeMake(0, 0);


    
     // There is a line above the button
     UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, dialogContainer.bounds.size.height - buttonHeight - buttonSpacerHeight, dialogContainer.bounds.size.width, buttonSpacerHeight)];
     lineView.backgroundColor = [UIColor colorWithRed:198.0/255.0 green:198.0/255.0 blue:198.0/255.0 alpha:1.0f];
     [dialogContainer addSubview:lineView];


    
     // 사용자 정의 컨테이너 최종 추가
     [dialogContainer addSubview:containerView];

     return dialogContainer;
}

@end








// ---------------------------------------------------------------------
// NetFunnelDefaultWaitView - (사용자 정의 컨테이너 - 내부 작업 등)
// ---------------------------------------------------------------------
@implementation CustomWaitView

-(id)init{
    self = [super init];
    
    if (self) {
        _title = nil;
        _waittm = nil;
        _contents = nil;
        _footer = nil;
        _progress = nil;
        _stop = nil;
        
        _directionNfTmp = 0;
    }
    return self;
}

- (UIView *)createWaitView
{
    //NSLog(@"aimtog: %s","createWaitView");
    UIView *demoView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 280, 125)];
    
    _title = [[UILabel alloc] initWithFrame:CGRectMake(20,10,240,20)];
    _title.textAlignment = ALIGN_LEFT;
    [demoView addSubview:_title];
    
    _waittm = [[UILabel alloc] initWithFrame:CGRectMake(20,30,240,20)];
    _waittm.numberOfLines = 0;
    _waittm.textAlignment = ALIGN_RIGHT;
    [demoView addSubview:_waittm];
    
    _progress = [[UIProgressView alloc] initWithFrame:CGRectMake(20.0f, 50.0f, 240.0f, 10.0f)];
    [demoView addSubview:_progress];
    [_progress setProgressViewStyle: UIProgressViewStyleBar];
    [_progress setProgress:0];
    _progress.progressTintColor = RGB(42, 80, 155, 1);
    _progress.trackTintColor = RGB(182, 223, 253, 1);
    
    UIView *subText = [[UIView alloc] initWithFrame:CGRectMake(20, 60, 240, 55)];
    subText.layer.backgroundColor = [RGB(237, 237, 237, 1) CGColor];
    [demoView addSubview:subText];
    
    _contents = [[UILabel alloc] initWithFrame:CGRectMake(10,5,220,30)];
    _contents.numberOfLines = 0;
    _contents.textAlignment = ALIGN_LEFT;
    [subText addSubview:_contents];
    
    // 대기중지 메시지
    _footer = [[UILabel alloc] initWithFrame:CGRectMake(10,35,176,20)];
    _footer.textAlignment = ALIGN_LEFT;
    [subText addSubview:_footer];
    
    // @@@@ "대기중지" 버튼
     _stop = [[UIButton alloc] initWithFrame:CGRectMake(186,35,50,20)];
     [subText addSubview:_stop];
    
    
    
    
    //set - background color
    demoView.backgroundColor = [UIColor whiteColor];
    
    //set - shadow
    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRect:demoView.bounds];
    [demoView.layer setMasksToBounds:NO];
    [demoView.layer setShadowColor:[[UIColor blackColor] CGColor]];
    [demoView.layer setShadowOffset:CGSizeMake(0.0f, 0.0f)];
    [demoView.layer setShadowOpacity:0.0f];
    [demoView.layer setShadowRadius:7.0f];
    [demoView.layer setShadowPath:shadowPath.CGPath];


    
    return demoView;
}


    


-(void)show //대기시 수행 되는 부분
{
    NetFunnelWaitData *wdata = [self getWaitData];
    
    //추출데이터 목록
    NSLog(@"Show Called WaitData:");
    NSLog(@"    - WaitUser=%ld",(long)wdata._waitUser);   //대기자수
    NSLog(@"    - TotalWaitUser=%ld",(long)wdata._totalWaitUser);  //처음 접속시 대기자수
    NSLog(@"    - WaitTime=%ld",(long)wdata._waitTime); //대기시간
    NSLog(@"    - 처리량(tps)=%f",(float)wdata._tps);  //처리량 TPS
    NSLog(@"    - Progress=%f",(float)wdata._progress); //진행률(진행바 만들기용) 1이 되면 종료

    
    //방향전환 대기창 위치 체크
    UIDeviceOrientation deviceOrientation = [[UIDevice currentDevice] orientation];
    if(_directionNfTmp != (long)deviceOrientation) {
        _directionNfTmp = (long)deviceOrientation;
        if(_alert != nil){
            [_alert close];
            _alert = nil;
        }
    }
    
    //대기창 로직
    if(_alert == nil){
        //NSLog(@"create alert view----------------------------------------------------------");
        _alert = [[NetFunnelCustomAlertView alloc] initWithParentView:_pview];
        [_alert setContainerView:[self createWaitView]];
        [_alert show];
        
        
        // Label
        if(_title != nil){
            NSString *label_txt = @"서비스 ";
            NSString *label_txt2 = @"접속대기 중";
            NSString *label_txt3 = @"입니다.";
            
            NSArray *tdata = [[NSArray alloc] initWithObjects:
                              [[NSDictionary alloc] initWithObjectsAndKeys:label_txt,@"str",[self getTextStyle:TSTypeTitleBold],@"attr", nil],
                              [[NSDictionary alloc] initWithObjectsAndKeys:label_txt2,@"str",[self getTextStyle:TSTypeTitleBold2],@"attr", nil],
                              [[NSDictionary alloc] initWithObjectsAndKeys:label_txt3,@"str",[self getTextStyle:TSTypeTitleBold],@"attr", nil],
                              nil];
            [self setStyleTextWithLabel:_title data:tdata];
        }
        
        // Last Text
        if(_footer != nil){
            NSString *label_txt = @"※ 재 접속하시면 대기시간이 더 길어집니다.";
            if([[[UIDevice currentDevice] systemVersion] intValue] < 6){
                label_txt = @"";
            }
            NSArray *tdata = [[NSArray alloc] initWithObjects:
                              [[NSDictionary alloc] initWithObjectsAndKeys:label_txt,@"str",[self getTextStyle:TSTypeFooterBold],@"attr", nil],
                              nil];
            
            [self setStyleTextWithLabel:_footer data:tdata];
        }
        
        // @@@@ "대기중지" 버튼
        if(_stop != nil){
            NSDictionary *tdata = [self getTextStyle:TSTypeFooterBold];
            UIFont *t_font = [tdata objectForKey:NSFontAttributeName];
            UIColor *t_color = [tdata objectForKey:NSForegroundColorAttributeName];
            
            _stop.titleLabel.font = t_font;
            [_stop setTitle:@"[대기중지]" forState:UIControlStateNormal];
            [_stop setTitleColor:t_color forState:UIControlStateNormal];
            [_stop addTarget:self action:@selector(stopButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    
    // Wait User
    if(_waittm != nil){
        float wait_tm;
        NSInteger nwait = wdata._waitUser;
        float tps = wdata._tps;
        if(tps < 1.0) tps = 1.0;
        if(tps > 0){
            wait_tm = nwait / tps;
        }else{
            wait_tm = nwait / tps;
        }
        if(wait_tm < 1){
            wait_tm = 1;
        }
        
        NSString *label_txt = @"예상대기시간 : ";
        NSString *label_txt2 = [NSString stringWithFormat:@"%ld",(long)wait_tm];
        NSString *label_txt3 = @"초";
        
        NSArray *tdata = [[NSArray alloc] initWithObjects:
                          [[NSDictionary alloc] initWithObjectsAndKeys:label_txt,@"str",[self getTextStyle:TSTypeWaitTimeNormal],@"attr", nil],
                          [[NSDictionary alloc] initWithObjectsAndKeys:label_txt2,@"str",[self getTextStyle:TSTypeWaitTimeBold],@"attr", nil],
                          [[NSDictionary alloc] initWithObjectsAndKeys:label_txt3,@"str",[self getTextStyle:TSTypeWaitTimeNormal],@"attr", nil],
                          nil];
        
        [self setStyleTextWithLabel:_waittm data:tdata];
    }
    
    // SetProgress
    if(_progress != nil){
        
        NSInteger tot_wait = wdata._totalWaitUser;
        NSInteger cur_wait = wdata._waitUser;
        
        
        if(cur_wait > tot_wait){
            tot_wait = cur_wait;
        }
        
        float ratio = wdata._progress;
        [_progress setProgress:ratio animated:YES];
    }
    
    // Wait User
    if(_contents != nil){
        
        NSString *label_txt = @"고객님 앞에 ";
        NSString *label_txt2 = [NSString stringWithFormat:@"%ld",(long)wdata._waitUser];
        
        NSString *label_txt3 = @" 명의 대기자가 있습니다.\n현재 접속 사용자가 많아 대기 중이며, 잠시만 기다리시면\n서비스로 자동 접속됩니다.";
        if([[[UIDevice currentDevice] systemVersion] intValue] < 6){
            label_txt3 = @" 명의 대기자가 있습니다.";
        }
        
        NSArray *tdata = [[NSArray alloc] initWithObjects:
                          [[NSDictionary alloc] initWithObjectsAndKeys:label_txt,@"str",[self getTextStyle:TSTypeContentNormal],@"attr", nil],
                          [[NSDictionary alloc] initWithObjectsAndKeys:label_txt2,@"str",[self getTextStyle:TSTypeContentBold],@"attr", nil],
                          [[NSDictionary alloc] initWithObjectsAndKeys:label_txt3,@"str",[self getTextStyle:TSTypeContentNormal],@"attr", nil],
                          nil];
        
        [self setStyleTextWithLabel:_contents data:tdata];
        [_contents sizeToFit];
    }
    
}

-(void)hide
{
    if(_alert != nil){
        NSLog(@"Hide Called WaitData:");
        [_alert close]; //대기창 닫기 처리
        _alert = nil;
    }
}

// @@@@ "대기중지"
-(void)stopButtonClick:(id)sender
{
    [self setStop]; //종료 처리
    if(_alert != nil){
        [_alert close]; //대기창 닫기 처리
        _alert = nil;
    }
}

-(void)showVirtualWait
{
    NSLog(@"Show VirtualWait Called WaitData:");
}

-(void)showBlockAlert{ //서비스 차단시 수행되는 부분
    NSLog(@"Show BlockAlert Called WaitData:");
}


@end
