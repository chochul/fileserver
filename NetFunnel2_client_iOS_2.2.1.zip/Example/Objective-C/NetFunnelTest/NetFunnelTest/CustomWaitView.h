//
//  CustomWaitView.h
//  NetFunnelTest
//
//  Created by Aimtog on 10/05/2019.
//  Copyright © 2019 Aimtog. All rights reserved.
//

#ifndef NetFunnelTest_CustomWaitView_h
#define NetFunnelTest_CustomWaitView_h

#import <NetFunnel/NetFunnelWaitView.h>



// ---------------------------------------------------------------------
// NetFunnelWaitView
// ---------------------------------------------------------------------
@interface CustomWaitView : NetFunnelWaitView <NetFunnelWaitViewProtocol> {
    
    //대기창 테스트
    NetFunnelCustomAlertView *_alert;
    
    UIProgressView *_progress;
    UILabel *_title;
    UILabel *_waittm;
    UILabel *_contents;
    UILabel *_footer;
    UIButton *_stop;
    NSInteger _last_wait_tm;
    
    //테스트 마지막줄
    NSInteger _directionNfTmp;
    
}

-(UIView *)createWaitView;
-(void)stopButtonClick:(id)sender;

@end

#endif
