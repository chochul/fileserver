//
//  ViewController.m
//  NetFunnelTest
//
//  Created by Aimtog on 10/05/2019.
//  Copyright © 2019 Aimtog. All rights reserved.
//

#import "ViewController.h"
#import "CustomWaitView.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



- (void)initValue:(NSString *)nid
{
//    [NetFunnel setGlobalConfigObject:@"192.168.100.194" forKey:@"host" withId:nid];
//    [NetFunnel setGlobalConfigObject:@"80" forKey:@"port" withId:nid];
//    [NetFunnel setGlobalConfigObject:@"service_2" forKey:@"service_id" withId:nid];
//    [NetFunnel setGlobalConfigObject:@"action_L" forKey:@"action_id" withId:nid];
    [NetFunnel setGlobalConfigObject:@"nf2.netfunnel.co.kr" forKey:@"host" withId:nid];
    [NetFunnel setGlobalConfigObject:@"http" forKey:@"proto" withId:nid];
    [NetFunnel setGlobalConfigObject:@"80" forKey:@"port" withId:nid];
    [NetFunnel setGlobalConfigObject:@"service_6" forKey:@"service_id" withId:nid];
    [NetFunnel setGlobalConfigObject:@"apptest" forKey:@"action_id" withId:nid];
}

- (IBAction)actionClick:(id)sender
{
    [self initValue:nil];
    
    // CustomWaitView를 설정
    [[[NetFunnel alloc] initWithDelegate:self pView:self.view] action];
}

- (IBAction)action2Click:(id)sender
{
    NSString *nid = @"2";
    [self initValue:nid];
    
    // CustomWaitView를 설정
    [NetFunnel setGlobalConfigObject:[[CustomWaitView alloc] initWithParentView:self.view] forKey:@"wait_view_object" withId:nid];
    [[[NetFunnel alloc] initWithDelegate:self pView:self.view] actionWithNid:nid config:nil ];
}

- (IBAction)action3Click:(id)sender
{
    NSString *nid = @"3";
    [self initValue:nid];
    
    // CustomWaitView를 설정
    [[[NetFunnel alloc] initWithDelegate:self pView:self.view] actionWithNid:nid config:
     [[NSDictionary alloc] initWithObjectsAndKeys:@"service_6",@"service_id",@"apptest",@"action_id", nil]
     ];
}

- (IBAction)completeClick:(id)sender
{
    if(![[[NetFunnel alloc] initWithDelegate:self pView:self.view] complete]){
        NSLog(@"Complete Error");
    }
}

- (IBAction)complete2Click:(id)sender
{
    if(![[[NetFunnel alloc] initWithDelegate:self pView:self.view] completeWithNid:@"2" config:nil]){
        NSLog(@"Complete Error");
    }
}


// NetFunnel Delegate!!
-(void)NetFunnelActionSuccess:(NSString *)nid withResult:(NetFunnelResult *)result
{
    NSLog(@"Action Success Called [nid=%@,result=%@",nid,result);
}
-(void)NetFunnelCompleteSuccess:(NSString *)nid withResult:(NetFunnelResult *)result
{
    NSLog(@"Complete Success Called [nid=%@,result=%@",nid,result);
}
-(BOOL)NetFunnelActionContinue:(NSString *)nid withResult:(NetFunnelResult *)result
{
    NSLog(@"ActionContinue Called [nid=%@,result=%@",nid,result);
    if(nid != nil && [nid isEqualToString:@"3"]){
        return NO;
    }
    return YES;
}
-(void)NetFunnelStop:(NSString *)nid
{
    NSLog(@"Stop Called [nid=%@]",nid);
}

//연결이 안되어 bypass 될 경우 ActionError Method는 특별한 수행이 없다면 삭제를 권장(bypass도 성공으로 리턴된다. 즉 위 ActionSuccess 호출됨)
-(void)NetFunnelActionError:(NSString *)nid withResult:(NetFunnelResult *)result
{
    NSLog(@"Error Called [nid=%@,result=%@",nid,result);
}



@end
