//
//  NetFunnelInfoStorage.h
//  NetFUNNEL
//
//  Created by Aimtog on 10/05/2019.
//  Copyright © 2019 Aimtog. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetFunnelResult.h"
#import "NetFunnelDefine.h"

// ---------------------------------------------------------------------
// NetFunnelInfoStorageItem
// ---------------------------------------------------------------------
@interface NetFunnelInfoStorageItem : NSObject {
    NSMutableDictionary *_config;
    NetFunnelResult *_result;
}
@property (nonatomic) NSMutableDictionary *_config;
@property (nonatomic) NetFunnelResult *_result;

-(void)setDefaultAll;
-(void)clearResult;
@end

// ---------------------------------------------------------------------
// NetFunnelInfoStorage
// ---------------------------------------------------------------------
@interface NetFunnelInfoStorage : NSObject {
    NSMutableDictionary *_data;
}

+(NetFunnelInfoStorage *)sharedObject;
-(NetFunnelInfoStorageItem *)itemForKey:(NSString *)key;
-(void)clearResult:(NSString *)key;
@end

